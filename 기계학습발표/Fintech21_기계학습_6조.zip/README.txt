6조 코드 및 데이터

codes
    - DM_EDA_1.ipynb | EDA 코드1
    - DM_EDA_2.ipynb | EDA 코드2
    - DM_Ensemble.ipynb | 앙상블 코드
    - DM_FE.ipynb | Feature Engineering 코드
    - DM_Model_Boost.ipynb | Boost계열 단일 모델 개발 코드
    - DM_Model_KNN_LR.ipynb | KNN, LogisticRegression 단일 모델 개발 코드
    - DM_Model_RF.ipynb | RandomForest 단일 모델 개발 코드
    - DM_PP_1.ipynb | 전처리 코드1
    - DM_PP_2.ipynb | 전처리 코드2

data
    - bank-additional-full.csv | 원본 데이터
    - bank-additional-full.csv | 원본 데이터에 대한 Description
    - preprocessed | 전처리된 Data Set

models | 개별 모델 객체 및 예측 결과값